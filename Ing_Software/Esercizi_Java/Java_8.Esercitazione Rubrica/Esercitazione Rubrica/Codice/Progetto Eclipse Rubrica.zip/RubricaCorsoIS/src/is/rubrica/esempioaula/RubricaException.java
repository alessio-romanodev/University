package is.rubrica.esempioaula;

/*
 * Tutta la classe e' stata generata in automatico da Eclipse: i costruttori
 * sono stati implementati utilizzando quelli offerti dalla classe padre.
 * 
 * "Source -> Generate Constructors from Superclass..."
 */
public class RubricaException extends Exception {

	public RubricaException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public RubricaException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public RubricaException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public RubricaException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public RubricaException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
}
