package is.rubrica.esempioLista;

public class ListaContattoException extends Exception {

	public ListaContattoException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}
