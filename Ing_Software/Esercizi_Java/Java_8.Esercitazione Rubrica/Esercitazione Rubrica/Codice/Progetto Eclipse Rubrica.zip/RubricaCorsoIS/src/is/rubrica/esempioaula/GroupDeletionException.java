package is.rubrica.esempioaula;

/*
 * Tutta la classe e' stata generata in automatico da Eclipse: i costruttori
 * sono stati implementati utilizzando quelli offerti dalla classe padre.
 * 
 * "Source -> Generate Constructors from Superclass..."
 */
public class GroupDeletionException extends RubricaException {

	public GroupDeletionException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public GroupDeletionException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public GroupDeletionException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public GroupDeletionException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public GroupDeletionException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
