package is.rubrica.esempioaula;

/*
 * Tutta la classe e' stata generata in automatico da Eclipse: i costruttori
 * sono stati implementati utilizzando quelli offerti dalla classe padre.
 * 
 * "Source -> Generate Constructors from Superclass..."
 */
public class ContattoNotInRubricaException extends RubricaException {

	public ContattoNotInRubricaException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ContattoNotInRubricaException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public ContattoNotInRubricaException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public ContattoNotInRubricaException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public ContattoNotInRubricaException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
